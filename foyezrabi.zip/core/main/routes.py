"""
Main page routes.
"""


from ..rapid.myapi import get_email
import requests
import json
import uuid
import os
from urllib.parse import urlparse
from flask import (
    render_template, request, current_app, make_response, send_from_directory
)

from . import main
from .config import Config


@main.route("/myapi/get-email/<url>")
def email(url):
    return get_email(url)


@main.route("/")
@main.route("/home/", strict_slashes=False)
def home():
    page_title = 'home'
    return render_template(
        'index.html',
        page_title=page_title
    )


@main.route("/price/", strict_slashes=False)
def price():
    page_title = 'Price'
    return render_template(
        'price.html',
        page_title=page_title
    )


@main.route("/application/", strict_slashes=False)
def application():
    page_title = 'application'
    return render_template(
        'application.html',
        page_title=page_title
    )


@main.route('/favicon.ico')
def favicon():
    return send_from_directory(
        os.path.join(current_app.root_path, 'static'),
        'img/favicon.ico'
    )


@main.route("/course/", strict_slashes=False)
def course():
    page_title = 'courses'
    return render_template(
        'course.html',
        page_title=page_title
    )

@main.route("/download_popup/")
def download_popup():
    page_title = 'download_popup'
    return render_template(
        'popup.html',
        page_title=page_title
    )


@main.route("/note/", strict_slashes=False)
def note():
    page_title = 'note'
    return render_template(
        'note.html',
        page_title=page_title
    )


@main.route("/content")
def content():
    url = f"https://www.googleapis.com/youtube/v3/search?part=snippet&channelId={Config.CHANNEL_ID}&maxResults=50&type=video&key={Config.YOUTUBE_API}"
    response = requests.get(url)
    videos = []
    if response.status_code == 200:
        data = json.loads(response.content.decode("utf-8"))
        for item in data["items"]:
            video = {
                "title": item["snippet"]["title"],
                "thumbnail": item["snippet"]["thumbnails"]["high"]["url"],
                "video_id": item["id"]["videoId"],
            }
            videos.append(video)
    # return videos
    return render_template("content.html", videos=videos)


@main.route("/sitemap/", strict_slashes=False)
@main.route("/sitemap.xml/", strict_slashes=False)
def sitemap():
    host_components = urlparse(request.host_url)
    host_base = host_components.scheme + "://" + host_components.netloc

    static_urls = list()
    for rule in current_app.url_map.iter_rules():
        if (
                not str(rule).startswith("/21fh08/"),
                not str(rule).startswith("/errors/")
        ):
            if "GET" in rule.methods and len(rule.arguments) == 0:
                url = {
                    "loc": f"{host_base}{str(rule)}",
                    "changefreq": "weekly",
                    "priority": "0.9"
                }
                static_urls.append(url)

    xml_sitemap = render_template(
        "sitemap.xml",
        static_urls=static_urls,
        host_base=host_base
    )
    response = make_response(xml_sitemap)
    response.headers["Content-Type"] = "application/xml"

    return response
