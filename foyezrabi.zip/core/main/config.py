"""
Flask app configuration.
Set Flask configuration from environment variables
"""


class Config:
    # DEBUG = False
    # TESTING = False
    # DEVELOPMENT = False

    SITE_NAME = "hiiiiiiiiiiiiiiiiiiiiiiiiii"
    YOUTUBE_API = "AIzaSyCxc5Y6p6oGAzsDi0kD9rZGqSIlwHdIzh0"
    CHANNEL_ID = "UCIFbnPw_X_gdz4ai2U9-TFQ"
