from flask import Flask, render_template, request, url_for, redirect, send_file, session
from io import BytesIO
from .backend import Downloader
import os
downloader = Downloader()
def create_app():
    app = Flask(__name__)
    app.config['SECRET_KEY'] = "654c0fb3968af9d5e6a9b3edcbc7051b"

    with app.app_context():
        from .main import main as main_blueprint
        app.register_blueprint(main_blueprint)

        @app.errorhandler(404)
        def pageNotFound(error):
            page_title = f"{error.code} - Page not found !"
            return render_template(
                'page/error.html',
                page_title=page_title,
                error=error
            ), 404

        @app.errorhandler(500)
        def internalServerError(error):
            page_title = f"{error.code} - few things went wrong"
            return render_template(
                'page/error.html',
                page_title=page_title,
                error=error
            ), 500

        @app.errorhandler(400)
        def keyError(error):
            page_title = f"{error.code} - invalid request resulted in KeyError."
            return render_template(
                'page/error.html',
                page_title=page_title,
                error=error
            ), 400

        @app.context_processor
        def override_url_for():
            return dict(url_for=dated_url_for)

        def dated_url_for(endpoint, **values):
            if endpoint == 'static':
                filename = values.get('filename', None)
                if filename:
                    file_path = os.path.join(app.root_path,
                                             endpoint, filename)
                    values['q'] = int(os.stat(file_path).st_mtime)
            return url_for(endpoint, **values)

        @app.route("/download", methods=["POST", "GET"])
        def home():

            if request.method == "POST":
                buffer = BytesIO()

                try:
                    if "video_button" in request.form:
                        quality_list = request.form["video_button"].split(",")
                        video = downloader.find_video(quality_list[0], quality_list[1])
                        # fname = downloader.download(video)
                        # return send_file(fname, as_attachment=True)
                        name = f"{video.title}.mp4"
                        video.stream_to_buffer(buffer)
                        buffer.seek(0)
                        return send_file(buffer, as_attachment=True, download_name=name, mimetype="video/mp4")


                    elif "audio_button" in request.form:
                        video = downloader.find_audio(request.form["audio_button"])
                        name = f"{video.title}.mp3"

                        video.stream_to_buffer(buffer)
                        buffer.seek(0)
                        return send_file(buffer, as_attachment=True, download_name=name, mimetype="video/mp3")





                    elif "audiovideo_button" in request.form:
                        quality_list = request.form["audiovideo_button"].split(",")
                        video = downloader.find_audio_videos(quality_list[0], quality_list[1], quality_list[2])

                        name = f"{video.title}.mp4"
                        video.stream_to_buffer(buffer)
                        buffer.seek(0)
                        return send_file(buffer, as_attachment=True, download_name=name, mimetype="video/mp4")

                    else:
                        url = request.form["ur"]
                        session["url"] = url
                        downloader.set_url(session["url"])
                        videos = downloader.get_videos()
                        audios = downloader.get_audios()
                        audiovideos = downloader.get_audio_videos()
                        title = downloader.get_title()
                        thumbnail = downloader.get_thumbnail()
                        views = downloader.get_views()
                        duration = downloader.get_duration()

                        return render_template("ythtml/ythome.html", url=session["url"], videos=videos, audios=audios,
                                               audiovideos=audiovideos, title=title, thumbnail=thumbnail, views=views,
                                               duration=duration)
                except Exception as e:
                    print(e)
                    return render_template("page/error.html", url="")

            else:
                if "url" in session:
                    return render_template("ythtml/ythome.html", url=session["url"])
                else:
                    return render_template("ythtml/ythome.html", url="")

        return app
