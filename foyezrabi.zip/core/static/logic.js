const words = ['Html', 'Css', 'JavaScript', 'Python', 'Hacking'];
let i = 0;
let j = 0;
let currentWord = '';
let isDeleting = false;

function type() {
  currentWord = words[i].substring(0, j);
  document.getElementById('word').innerHTML = currentWord;
  if (isDeleting) {
    j--;
  } else {
    j++;
  }
  if (j > words[i].length) {
    isDeleting = true;
    j = words[i].length;
  } else if (j < 1) {
    isDeleting = false;
    i = (i + 1) % words.length;
  }
  if (j === words[i].length && isDeleting) {
    setTimeout(type, 1000); // pause for 1 second
  } else {
    setTimeout(type, 20); // random timeout between 50 and 150 ms
  }
}

type();

function myFunction() {
  var x = document.getElementById("myLinks");
  if (x.style.display === "block") {
    x.style.display = "none";
  } else {
    x.style.display = "block";
  }
}